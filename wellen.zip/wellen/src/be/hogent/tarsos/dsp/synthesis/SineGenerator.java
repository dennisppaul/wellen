/*
 *      _______                       _____   _____ _____
 *     |__   __|                     |  __ \ / ____|  __ \
 *        | | __ _ _ __ ___  ___  ___| |  | | (___ | |__) |
 *        | |/ _` | '__/ __|/ _ \/ __| |  | |\___ \|  ___/
 *        | | (_| | |  \__ \ (_) \__ \ |__| |____) | |
 *        |_|\__,_|_|  |___/\___/|___/_____/|_____/|_|
 *
 * -----------------------------------------------------------
 *
 *  TarsosDSP is developed by Joren Six at
 *  The Royal Academy of Fine Arts & Royal Conservatory,
 *  University College Ghent,
 *  Hoogpoort 64, 9000 Ghent - Belgium
 *
 *  http://tarsos.0110.be/tag/TarsosDSP
 *  https://github.com/JorenSix/TarsosDSP
 *  http://tarsos.0110.be/releases/TarsosDSP/
 *
 */
package be.hogent.tarsos.dsp.synthesis;

import be.hogent.tarsos.dsp.AudioEvent;
import be.hogent.tarsos.dsp.AudioProcessor;

public class SineGenerator implements AudioProcessor {

    private double frequency;
    private double gain;
    private double phase;

    public SineGenerator() {
        this(1.0, 440);
    }

    public SineGenerator(double gain, double frequency) {
        this.gain = gain;
        this.frequency = frequency;
        this.phase = 0;
    }

    @Override
    public boolean process(AudioEvent audioEvent) {
        float[] buffer = audioEvent.getFloatBuffer();
        double sampleRate = audioEvent.getSampleRate();
        double twoPiF = 2 * Math.PI * frequency;
        double time = 0;
        for (int i = 0; i < buffer.length; i++) {
            time = i / sampleRate;
            buffer[i] += (float) (gain * Math.sin(twoPiF * time + phase));
        }
        phase = twoPiF * buffer.length / sampleRate + phase;
        return true;
    }

    @Override
    public void processingFinished() {
    }
}
