/*
 *      _______                       _____   _____ _____
 *     |__   __|                     |  __ \ / ____|  __ \
 *        | | __ _ _ __ ___  ___  ___| |  | | (___ | |__) |
 *        | |/ _` | '__/ __|/ _ \/ __| |  | |\___ \|  ___/
 *        | | (_| | |  \__ \ (_) \__ \ |__| |____) | |
 *        |_|\__,_|_|  |___/\___/|___/_____/|_____/|_|
 *
 * -----------------------------------------------------------
 *
 *  TarsosDSP is developed by Joren Six at
 *  The Royal Academy of Fine Arts & Royal Conservatory,
 *  University College Ghent,
 *  Hoogpoort 64, 9000 Ghent - Belgium
 *
 *  http://tarsos.0110.be/tag/TarsosDSP
 *  https://github.com/JorenSix/TarsosDSP
 *  http://tarsos.0110.be/releases/TarsosDSP/
 *
 */

package be.hogent.tarsos.dsp.example;

import be.hogent.tarsos.dsp.AudioDispatcher;
import be.hogent.tarsos.dsp.AudioEvent;
import be.hogent.tarsos.dsp.AudioProcessor;
import be.hogent.tarsos.dsp.SilenceDetector;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

public class SoundDetector extends JFrame implements AudioProcessor {

    /**
     *
     */
    private static final long serialVersionUID = 3501426880288136245L;
    ArrayList<Clip> clipList;
    int counter;
    Mixer currentMixer;
    AudioDispatcher dispatcher;
    SilenceDetector silenceDetector;
    double threshold;
    private final GaphPanel graphPanel;
    private final JTextArea textArea;

    public SoundDetector() {
        this.setLayout(new BorderLayout());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Sound Detector");
        this.threshold = SilenceDetector.DEFAULT_SILENCE_THRESHOLD;

        JPanel inputPanel = new InputPanel();
        //add(inputPanel);
        inputPanel.addPropertyChangeListener("mixer", new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent arg0) {
                try {
                    setNewMixer((Mixer) arg0.getNewValue());
                } catch (LineUnavailableException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (UnsupportedAudioFileException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });


        JSlider thresholdSlider = initialzeThresholdSlider();
        JPanel params = new JPanel(new BorderLayout());
        params.setBorder(new TitledBorder("2. Set the algorithm parameters"));

        JLabel label = new JLabel("Threshold");
        label.setToolTipText("Energy level when sound is counted (dB SPL).");
        params.add(label, BorderLayout.NORTH);
        params.add(thresholdSlider, BorderLayout.CENTER);

        JPanel inputAndParamsPanel = new JPanel(new BorderLayout());
        inputAndParamsPanel.add(inputPanel, BorderLayout.NORTH);
        inputAndParamsPanel.add(params, BorderLayout.SOUTH);


        JPanel panelWithTextArea = new JPanel(new BorderLayout());
        textArea = new JTextArea(8, 30);
        textArea.setEditable(false);
        panelWithTextArea.add(inputAndParamsPanel, BorderLayout.NORTH);
        panelWithTextArea.add(new JScrollPane(textArea), BorderLayout.CENTER);

        add(panelWithTextArea, BorderLayout.NORTH);


        graphPanel = new GaphPanel(threshold);
        graphPanel.setSize(80, 100);
        add(graphPanel, BorderLayout.CENTER);
    }

    @Override
    public boolean process(AudioEvent audioEvent) {
        handleSound();
        return true;
    }

    @Override
    public void processingFinished() {

    }

    private void handleSound() {
        if (silenceDetector.currentSPL() > threshold) {
            textArea.append("Sound detected at:" + System.currentTimeMillis() + ", " + (int) (silenceDetector.currentSPL()) + "dB SPL\n");
            textArea.setCaretPosition(textArea.getDocument().getLength());
        }
        graphPanel.addDataPoint(silenceDetector.currentSPL(), System.currentTimeMillis());
    }

    private JSlider initialzeThresholdSlider() {
        JSlider thresholdSlider = new JSlider(-120, 0);
        thresholdSlider.setValue((int) threshold);
        thresholdSlider.setPaintLabels(true);
        thresholdSlider.setPaintTicks(true);
        thresholdSlider.setMajorTickSpacing(20);
        thresholdSlider.setMinorTickSpacing(10);
        thresholdSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JSlider source = (JSlider) e.getSource();
                threshold = source.getValue();
                graphPanel.setThresholdLevel(threshold);
                if (!source.getValueIsAdjusting()) {
                    try {
                        setNewMixer(currentMixer);
                    } catch (LineUnavailableException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    } catch (UnsupportedAudioFileException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                }
            }
        });
        return thresholdSlider;
    }

    private void setNewMixer(Mixer mixer) throws LineUnavailableException, UnsupportedAudioFileException {

        if (dispatcher != null) {
            dispatcher.stop();
        }
        currentMixer = mixer;

        float sampleRate = 44100;
        int bufferSize = 512;
        int overlap = 0;

        textArea.append("Started listening with " + mixer.getMixerInfo()
                                                         .getName() + "\n\tparams: " + threshold + "dB\n");

        final AudioFormat format = new AudioFormat(sampleRate, 16, 1, true, true);
        final DataLine.Info dataLineInfo = new DataLine.Info(TargetDataLine.class, format);
        TargetDataLine line;
        line = (TargetDataLine) mixer.getLine(dataLineInfo);
        final int numberOfSamples = bufferSize;
        line.open(format, numberOfSamples);
        line.start();
        final AudioInputStream stream = new AudioInputStream(line);

        // create a new dispatcher
        dispatcher = new AudioDispatcher(stream, bufferSize, overlap);

        // add a processor, handle percussion event.
        silenceDetector = new SilenceDetector(threshold, false);
        dispatcher.addAudioProcessor(silenceDetector);
        dispatcher.addAudioProcessor(this);

        // run the dispatcher (on a new thread).
        new Thread(dispatcher, "Audio dispatching").start();
    }

    private static class GaphPanel extends JPanel {

        /**
         *
         */
        private static final long serialVersionUID = 5969781241442094359L;
        private long currentModulo = System.currentTimeMillis() / 15000;
        private List<Double> levels;
        private double maxLevel = -1000;
        private List<Long> startTimes;
        private double threshold;

        public GaphPanel(double defaultThreshold) {
            setThresholdLevel(defaultThreshold);
            levels = new ArrayList<Double>();
            startTimes = new ArrayList<Long>();
            setMinimumSize(new Dimension(80, 60));
        }

        public void setThresholdLevel(double newThreshold) {
            threshold = newThreshold;
            repaint();
        }

        public void addDataPoint(double level, long ms) {
            levels.add(level);
            startTimes.add(ms);
            setMaxLevel(level);
            repaint();
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g); //paint background
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, getWidth(), getHeight());

            if (System.currentTimeMillis() / 15000 > currentModulo) {
                currentModulo = System.currentTimeMillis() / 15000;
                levels.clear();
                startTimes.clear();
            }


            for (int i = 0; i < levels.size(); i++) {
                g.setColor(levels.get(i) > threshold ? Color.GREEN : Color.ORANGE);
                int x = msToXCoordinate(startTimes.get(i));
                int y = levelToYCoordinate(levels.get(i));
                g.drawLine(x, y, x + 1, y);
            }

            int thresholdYCoordinate = levelToYCoordinate(threshold);
            g.setColor(Color.ORANGE);
            g.drawLine(0, thresholdYCoordinate, getWidth(), thresholdYCoordinate);
            g.drawString(String.valueOf((int) threshold), 0, thresholdYCoordinate + 15);


            int maxYCoordinate = levelToYCoordinate(maxLevel);
            g.setColor(Color.RED);
            g.drawLine(0, maxYCoordinate, getWidth(), maxYCoordinate);
            g.drawString(String.valueOf(((int) (maxLevel * 100)) / 100.0), getWidth() - 40, maxYCoordinate + 15);

        }

        private int levelToYCoordinate(double level) {
            int inPixels = (int) ((120 + level) / 120 * (getHeight() - 1));
            int yCoordinate = getHeight() - inPixels;
            return yCoordinate;
        }

        private int msToXCoordinate(long ms) {
            return (int) ((ms % 15000) / 15000.0 * getWidth());
        }

        private void setMaxLevel(double newMaxLevel) {
            if (newMaxLevel > maxLevel) {
                maxLevel = newMaxLevel;
            }
        }

    }

    public static void main(String... strings) throws InterruptedException, InvocationTargetException {
        SwingUtilities.invokeAndWait(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new SoundDetector();
                frame.pack();
                frame.setSize(640, 480);
                frame.setVisible(true);
            }
        });
    }


}
