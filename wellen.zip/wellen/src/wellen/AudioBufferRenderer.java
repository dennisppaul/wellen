package wellen;

public interface AudioBufferRenderer {

    void audioblock(float[][] pOutputSamples, float[][] pInputSamples);
}
