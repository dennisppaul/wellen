package wellen;

public interface DSPNodeProcess {

    float process(float pSignal);
}
