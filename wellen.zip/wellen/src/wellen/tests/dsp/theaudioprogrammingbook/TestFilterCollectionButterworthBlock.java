package wellen.tests.dsp.theaudioprogrammingbook;

import processing.core.PApplet;
import wellen.Wellen;
import wellen.dsp.DSP;
import wellen.dsp.OscillatorFunction;

public class TestFilterCollectionButterworthBlock extends PApplet {

    private FilterButterworthBlock mButterworthFilters;
    private int mButterworthType = FilterButterworthBlock.LOW_PASS;
    private float mFilterBandwidth = 10.0f;
    private float mFilterFrequency = 1000.0f;
    private int mFilterType = FilterCollectionBlock.LOW_PASS;
    private FilterCollectionBlock mFilters;
    private OscillatorFunction mOSCLeft;
    private OscillatorFunction mOSCRight;

    public void settings() {
        size(1024, 768);
    }

    public void setup() {
        mOSCLeft = new OscillatorFunction();
        mOSCLeft.set_frequency(2f * 48000f / 1024f);
        mOSCLeft.set_amplitude(0.5f);
        mOSCLeft.set_waveform(Wellen.WAVEFORM_SQUARE);

        mOSCRight = new OscillatorFunction();
        mOSCRight.set_frequency(2f * 48000f / 1024f);
        mOSCRight.set_amplitude(0.5f);
        mOSCRight.set_waveform(Wellen.WAVEFORM_SQUARE);

        mButterworthFilters = new FilterButterworthBlock(Wellen.DEFAULT_SAMPLING_RATE);
        mFilters = new FilterCollectionBlock(Wellen.DEFAULT_SAMPLING_RATE);

        Wellen.dumpAudioInputAndOutputDevices();
        DSP.start(this, 2);
    }

    public void draw() {
        background(255);
        stroke(0);
        DSP.draw_buffers(g, width, height);
    }

    public void mouseMoved() {
        mFilterFrequency = map(mouseX, 0, width, 1, 10000);
        mFilterBandwidth = map(mouseY, 0, height, 0.001f, 100);
        System.out.print(" frequency : " + mFilterFrequency);
        System.out.print(" bandwidth : " + mFilterBandwidth);
        System.out.print(" filtertype: " + mButterworthType);
        System.out.print(" filtertype: " + mFilterType);
        System.out.println();
    }

    public void keyPressed() {
        switch (key) {
            case '0':
                mButterworthType = -1;
                mFilterType = -1;
                break;
            case '1':
                mButterworthType = FilterButterworthBlock.LOW_PASS;
                mFilterType = FilterCollectionBlock.LOW_PASS;
                break;
            case '2':
                mButterworthType = FilterButterworthBlock.HIGH_PASS;
                mFilterType = FilterCollectionBlock.HIGH_PASS;
                break;
            case '3':
                mButterworthType = FilterButterworthBlock.BAND_PASS;
                mFilterType = FilterCollectionBlock.BAND_PASS;
                break;
            case '4':
                mButterworthType = FilterButterworthBlock.BAND_REJECT;
                mFilterType = FilterCollectionBlock.RESONATOR;
                break;
        }
    }

    public void audioblock(float[] output_signalLeft, float[] output_signalRight) {
        for (int i = 0; i < output_signalLeft.length; i++) {
            output_signalLeft[i] = mOSCLeft.output();
            output_signalRight[i] = mOSCRight.output();
        }
        mButterworthFilters.process(output_signalLeft, mFilterFrequency, mFilterBandwidth, mButterworthType);
        mFilters.process(output_signalRight, mFilterFrequency, mFilterBandwidth, mFilterType);
    }

    public static void main(String[] args) {
        PApplet.main(TestFilterCollectionButterworthBlock.class.getName());
    }
}
