package wellen.tests.dsp.theaudioprogrammingbook;

import processing.core.PApplet;
import wellen.Wellen;
import wellen.dsp.DSP;
import wellen.dsp.DSPNodeProcess;
import wellen.dsp.FilterBalance;
import wellen.dsp.FilterBandPass;
import wellen.dsp.FilterButterworth;
import wellen.dsp.FilterHighPass;
import wellen.dsp.FilterLowPass;
import wellen.dsp.FilterResonator;
import wellen.dsp.OscillatorFunction;

import static wellen.Wellen.FILTER_MODE_BAND_PASS;
import static wellen.Wellen.FILTER_MODE_BAND_REJECT;
import static wellen.Wellen.FILTER_MODE_HIGH_PASS;
import static wellen.Wellen.FILTER_MODE_LOW_PASS;

public class TestFilters extends PApplet {

    private FilterButterworth mButterworthFilters;
    private DSPNodeProcess mFirstOrderFilter;
    private FilterBalance mFilterBalance;
    private int mButterworthType = FILTER_MODE_LOW_PASS;
    private float mFilterBandwidth = 10.0f;
    private float mFilterFrequency = 1000.0f;
    private OscillatorFunction mOSCLeft;
    private OscillatorFunction mOSCRight;
    private boolean fUseBalanceFilter = false;

    public void settings() {
        size(1024, 768);
    }

    public void setup() {
        mOSCLeft = new OscillatorFunction();
        mOSCLeft.set_frequency(2f * Wellen.DEFAULT_SAMPLING_RATE / Wellen.DEFAULT_AUDIOBLOCK_SIZE);
        mOSCLeft.set_amplitude(0.5f);
        mOSCLeft.set_waveform(Wellen.WAVEFORM_SQUARE);

        mOSCRight = new OscillatorFunction();
        mOSCRight.set_frequency(2f * Wellen.DEFAULT_SAMPLING_RATE / Wellen.DEFAULT_AUDIOBLOCK_SIZE);
        mOSCRight.set_amplitude(0.5f);
        mOSCRight.set_waveform(Wellen.WAVEFORM_SQUARE);

        mButterworthFilters = new FilterButterworth();
        mFirstOrderFilter = new FilterLowPass();
        mFilterBalance = new FilterBalance();
        mFilterBalance.set_frequency(1000.0f);

        Wellen.dumpAudioInputAndOutputDevices();
        DSP.start(this, 2);
    }

    public void draw() {
        background(255);
        stroke(0);
        DSP.draw_buffers(g, width, height);
    }

    public void mouseMoved() {
        mFilterFrequency = map(mouseX, 0, width, 1, 10000);
        mFilterBandwidth = map(mouseY, 0, height, 0.001f, 100);
        mButterworthFilters.set_frequency(mFilterFrequency);
        mButterworthFilters.set_bandwidth(mFilterBandwidth);
        mFilterBalance.set_frequency(mFilterFrequency);

        if (mFirstOrderFilter instanceof FilterLowPass) {
            ((FilterLowPass) mFirstOrderFilter).set_frequency(mFilterFrequency);
        } else if (mFirstOrderFilter instanceof FilterHighPass) {
            ((FilterHighPass) mFirstOrderFilter).set_frequency(mFilterFrequency);
        } else if (mFirstOrderFilter instanceof FilterBandPass) {
            ((FilterBandPass) mFirstOrderFilter).set_frequency(mFilterFrequency);
            ((FilterBandPass) mFirstOrderFilter).set_bandwidth(mFilterBandwidth);
        } else if (mFirstOrderFilter instanceof FilterResonator) {
            ((FilterResonator) mFirstOrderFilter).set_frequency(mFilterFrequency);
            ((FilterResonator) mFirstOrderFilter).set_bandwidth(mFilterBandwidth);
        }
    }

    public void keyPressed() {
        switch (key) {
            case '0':
                mButterworthType = -1;
                break;
            case '1':
                mButterworthType = FILTER_MODE_LOW_PASS;
                mFirstOrderFilter = new FilterLowPass();
                break;
            case '2':
                mButterworthType = FILTER_MODE_HIGH_PASS;
                mFirstOrderFilter = new FilterHighPass();
                break;
            case '3':
                mButterworthType = FILTER_MODE_BAND_PASS;
                mFirstOrderFilter = new FilterBandPass();
                break;
            case '4':
                mButterworthType = FILTER_MODE_BAND_REJECT;
                mFirstOrderFilter = new FilterResonator();
                break;
            case ' ':
                fUseBalanceFilter = !fUseBalanceFilter;
                break;
        }
        mButterworthFilters.set_mode(mButterworthType);

        float mScale = 0;
        switch (key) {
            case '!':
                mScale = 0.5f;
                break;
            case '"':
                mScale = 1f;
                break;
            case '§':
                mScale = 2f;
                break;
            case '$':
                mScale = 4f;
                break;
        }
        if (mScale > 0) {
            mOSCLeft.set_frequency(mScale * Wellen.DEFAULT_SAMPLING_RATE / Wellen.DEFAULT_AUDIOBLOCK_SIZE);
            mOSCRight.set_frequency(mScale * Wellen.DEFAULT_SAMPLING_RATE / Wellen.DEFAULT_AUDIOBLOCK_SIZE);
        }
    }

    public void audioblock(float[] output_signalLeft, float[] output_signalRight) {
        for (int i = 0; i < output_signalLeft.length; i++) {
            output_signalLeft[i] = mOSCRight.output();
            output_signalLeft[i] = mButterworthFilters.process(output_signalLeft[i]);

            output_signalRight[i] = mOSCLeft.output();
            if (fUseBalanceFilter) {
                mFilterBalance.set_comparator_signal(output_signalRight[i]);
                output_signalRight[i] = mFilterBalance.process(mFirstOrderFilter.process(output_signalRight[i]));
            } else {
                output_signalRight[i] = mFirstOrderFilter.process(output_signalRight[i]);
            }
        }
    }

    public static void main(String[] args) {
        PApplet.main(TestFilters.class.getName());
    }
}
