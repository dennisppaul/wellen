package wellen.tests.dsp.filters;

import wellen.Wellen;

import static processing.core.PApplet.PI;
import static processing.core.PApplet.cos;
import static processing.core.PApplet.sin;

/**
 * Allows all frequencies to pass through while altering the phase relationship between different frequency components.
 * <p>
 * An all-pass filter is different from other filters in that it allows all frequencies to pass through the filter, but
 * it alters the phase relationship between different frequency components. The cutoff frequency in this implementation
 * is the frequency at which the phase shift is equal to 90 degrees.
 * <p>
 * This class implements a 2nd order all-pass filter using the difference equation:
 * <p>
 * <code>y[n] = a1 * x[n-1] + a2 * x[n-2] - b1 * y[n-1] - b2 * y[n-2]</code>
 * <p>
 * Where:
 * <ul>
 *     <li>x[n] is the input audio sample</li>
 *     <li>y[n] is the output audio sample</li>
 *     <li>a1, a2, b1, b2 are the filter coefficients</li>
 *     <li>x1, x2, y1, y2 are previous inputs and outputs used for filtering</li>
 *     <li>cutoff is the cutoff frequency of the filter</li>
 *     <li>sampleRate is the sample rate of the audio data</li>
 * </ul>
 */
public class AllPassFilter {

    private final float fSampleRate;
    // Filter coefficients
    private float a1, a2, b1, b2;
    private float cutoff;
    private float x1, x2, y1, y2;

    public AllPassFilter() {
        this(Wellen.DEFAULT_SAMPLING_RATE);
    }

    public AllPassFilter(float sample_rate) {
        fSampleRate = sample_rate;
        cutoff = 1000;
        update_coefficients();
    }

    public float get_cutoff() {
        return cutoff;
    }

    public void set_cutoff(float pCutoff) {
        cutoff = pCutoff;
    }

    public void update_coefficients() {
        final float omega = 2 * PI * cutoff / fSampleRate;
        final float sn = sin(omega);
        final float cs = cos(omega);
        final float alpha = sn / (2);

        a1 = -2 * cs;
        a2 = 1;
        b1 = a1;
        b2 = -alpha;
    }

    public float process(float input) {
        final float x = input;
        final float y = a1 * x1 + a2 * x2 - b1 * y1 - b2 * y2;

        x2 = x1;
        x1 = x;
        y2 = y1;
        y1 = y;

        return y;
    }
}
