package wellen.tests.dsp.filters;

import wellen.Wellen;
import wellen.dsp.DSPNodeProcess;

import static java.lang.Math.sinh;
import static processing.core.PApplet.PI;
import static processing.core.PApplet.cos;
import static processing.core.PApplet.log;
import static processing.core.PApplet.sin;

/**
 * A Notch filter is a filter that is used to remove a specific frequency or range of frequencies. This is useful for
 * removing unwanted noise or hum from an audio signal. The center frequency parameter in this example is the frequency
 * that you want to remove, and the bandwidth parameter is the range of frequencies around the center frequency that you
 * want to remove.
 * <p>
 * This class implements a 2nd order notch filter using the difference equation:
 * <p>
 * <code>y[n] = a0 * x[n] + a1 * x[n-1] + a2 * x[n-2] - b1 * y[n-1] - b2 * y[n-2]</code>
 * <p>
 * Where:
 * <ul>
 *     <li>x[n] is the input audio sample</li>
 *     <li>y[n] is the output audio sample</li>
 *     <li>a0, a1, a2, b1, b2 are the filter coefficients</li>
 *     <li>x1, x2, y1, y2 are previous inputs and outputs used for filtering</li>
 *     <li>center is the center frequency of the filter</li>
 *     <li>bandwidth is the bandwidth of the filter</li>
 *     <li>sampleRate is the sample rate of the audio data</li>
 * </ul>
 */
public class NotchFilter implements DSPNodeProcess {

    private final float fSampleRate;
    // Filter coefficients
    private float a0, a1, a2, b1, b2;
    private float bandwidth;
    private float center;
    private float x1, x2, y1, y2;

    public NotchFilter() {
        this(Wellen.DEFAULT_SAMPLING_RATE);
    }

    public NotchFilter(float sample_rate) {
        fSampleRate = sample_rate;
    }

    public float get_bandwidth() {
        return bandwidth;
    }

    public void set_bandwidth(float pBandwidth) {
        bandwidth = pBandwidth;
        update_coefficients();
    }

    public float get_center() {
        return center;
    }

    public void set_center(float pCenter) {
        center = pCenter;
        update_coefficients();
    }

    public void update_coefficients() {
        float omega = 2 * PI * center / fSampleRate;
        float sn = sin(omega);
        float cs = cos(omega);
        float alpha = (float) (sn * sinh(log(2) / 2 * bandwidth * omega / sn));

        a0 = 1;
        a1 = -2 * cs;
        a2 = 1;
        b1 = a1;
        b2 = (1 - alpha) / (1 + alpha);
    }

    public float process(float input) {
        float x = input;
        float y = a0 * x + a1 * x1 + a2 * x2 - b1 * y1 - b2 * y2;

        x2 = x1;
        x1 = x;
        y2 = y1;
        y1 = y;

        return y;
    }
}
