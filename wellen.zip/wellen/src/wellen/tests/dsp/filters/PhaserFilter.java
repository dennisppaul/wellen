package wellen.tests.dsp.filters;

import wellen.Wellen;
import wellen.dsp.DSPNodeProcess;

import java.util.Arrays;

import static processing.core.PApplet.PI;
import static processing.core.PApplet.sin;

/**
 * A Phaser filter is a filter that is used to create a "swirling" or "whooshing" effect by combining a comb filter with
 * all-pass filters. This filter uses a Low-Frequency Oscillator (LFO) to modulate the delay of a comb filter. The LFO
 * frequency parameter in this example controls the speed of the modulation, while the gain parameter controls the
 * amplitude of the delayed signal.
 * <p>
 * This class implements a phaser filter using the difference equation:
 * <p>
 * <code>y[n] = gain * x[n - delay * sin(lfoPhase)] + y[n - delay]</code>
 * <p>
 * Where:
 * <ul>
 *     <li>x[n] is the input audio sample</li>
 *     <li>y[n] is the output audio sample</li>
 *     <li>gain is the gain of the filter</li>
 *     <li>lfoFrequency is the LFO frequency of the filter</li>
 *     <li>sampleRate is the sample rate of the audio data</li>
 * </ul>
 */
public class PhaserFilter implements DSPNodeProcess {

    private final float fSampleRate;
    // Filter coefficients
    private float[] b;
    private int delay;
    private float fLFOFrequency;
    private float fLFOIncrement;
    private float fLFOPhase;
    private float gain;
    private int n;
    private float[] x;
    private float[] y;
    private float[] z;

    public PhaserFilter() {
        this(Wellen.DEFAULT_SAMPLING_RATE);
    }

    public PhaserFilter(float sample_rate) {
        fSampleRate = sample_rate;
    }

    public float get_LFO_frequency() {
        return fLFOFrequency;
    }

    public void set_LFO_frequency(float pLFO_frequency) {
        fLFOFrequency = pLFO_frequency;
        fLFOPhase = 0;
        fLFOIncrement = 2 * PI * fLFOFrequency / fSampleRate;

        delay = (int) (fSampleRate / fLFOFrequency);
        b = new float[delay];
        x = new float[delay];
        y = new float[delay];
        z = new float[delay];
        set_gain(gain);
        n = 0;
    }

    public float get_gain() {
        return gain;
    }

    public void set_gain(float pGain) {
        gain = pGain;
        Arrays.fill(b, gain);
    }

    public float process(float input) {
        // TODO really need to check if this works or if n should always be 0?!?
        final int nn = n % delay;
        x[nn] = input;
        y[nn] = 0;
        z[nn] = sin(fLFOPhase);
        fLFOPhase += fLFOIncrement;
        if (fLFOPhase >= 2 * Math.PI) {
            fLFOPhase -= 2 * Math.PI;
        }
        int k = (int) ((n - delay * z[nn]) % delay);
        if (k < 0) {
            k += delay;
        }
        y[nn] += b[k] * x[nn];
        n++;
        return y[nn];
    }

    public void process(float[] input, float[] output) {
        for (int i = 0; i < input.length; i++) {
            x[i % delay] = input[i];
            y[i % delay] = 0;
            z[i % delay] = sin(fLFOPhase);
            fLFOPhase += fLFOIncrement;
            if (fLFOPhase >= 2 * PI) {
                fLFOPhase -= 2 * PI;
            }
            int k = (int) ((i - delay * z[i % delay]) % delay);
            if (k < 0) {
                k += delay;
            }
            y[i % delay] += b[k] * x[i % delay];
            output[i] = y[i % delay];
        }
    }
}
