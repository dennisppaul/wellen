package wellen.tests.dsp.filters;

import wellen.Wellen;
import wellen.dsp.DSPNodeProcess;

import static processing.core.PApplet.PI;
import static processing.core.PApplet.cos;
import static processing.core.PApplet.pow;
import static processing.core.PApplet.sin;
import static processing.core.PApplet.sqrt;

/**
 * Amplifies or attenuates all frequencies above or below a certain cutoff frequency.
 * <p>
 * A shelving filter is a filter that has a constant gain or attenuation outside a certain frequency range, and a
 * variable gain or attenuation within that range. The gain parameter in this implementation is in dB and the cutoff
 * frequency is the frequency at which the gain begins to change.
 * <p>
 * This class implements a 2nd order shelving filter using the difference equation:
 * <p>
 * <code>y[n] = a0 * x[n] + a1 * x[n-1] + a2 * x[n-2] - b1 * y[n-1] - b2 * y[n-2]</code>
 * <p>
 * Where:
 * <ul>
 *     <li>x[n] is the input audio sample</li>
 *     <li>y[n] is the output audio sample</li>
 *     <li>a0, a1, a2, b1, b2 are the filter coefficients</li>
 *     <li>x1, x2, y1, y2 are previous inputs and outputs used for filtering</li>
 *     <li>cutoff is the cutoff frequency of the filter</li>
 *     <li>gain is the gain of the filter</li>
 *     <li>sampleRate is the sample rate of the audio data</li>
 *     <li>isHighPass is a boolean value indicating whether the filter is a high-pass or a low-pass shelving filter</li>
 * </ul>
 */
public class ShelvingFilter implements DSPNodeProcess {
    private final float fSampleRate;

    // Filter coefficients
    private float a0, a1, a2, b1, b2;
    private float cutoff;
    private float gain;
    private boolean is_high_pass;
    private float x1, x2, y1, y2;

    public ShelvingFilter() {
        this(Wellen.DEFAULT_SAMPLING_RATE);
    }

    public ShelvingFilter(float sample_rate) {
        fSampleRate = sample_rate;
    }

    public float get_cutoff() {
        return cutoff;
    }

    public void set_cutoff(float pCutoff) {
        cutoff = pCutoff;
        update_coefficients();
    }

    public float get_gain() {
        return gain;
    }

    public void set_gain(float pGain) {
        gain = pGain;
        update_coefficients();
    }

    public boolean is_high_pass() {
        return is_high_pass;
    }

    public void set_high_pass(boolean pIs_high_pass) {
        is_high_pass = pIs_high_pass;
        update_coefficients();
    }

    public void update_coefficients() {
        float omega = 2 * PI * cutoff / fSampleRate;
        float sn = sin(omega);
        float cs = cos(omega);
        float alpha = sn / 2;

        float A = pow(10, (gain / 40));
        float A_inv = 1 / A;

        final float a21 = (A + 1) + (A - 1) * cs - 2 * sqrt(A) * alpha;
        final float b21 = (A + 1) - (A - 1) * cs - 2 * sqrt(A) * alpha;
        if (is_high_pass) {
            a0 = (A + 1) + (A - 1) * cs + 2 * sqrt(A) * alpha;
            a1 = -2 * ((A - 1) + (A + 1) * cs);
            a2 = a21;
            b1 = 2 * ((A - 1) - (A + 1) * cs);
            b2 = b21;
        } else {
            a0 = (A + 1) - (A - 1) * cs + 2 * sqrt(A) * alpha;
            a1 = 2 * ((A - 1) - (A + 1) * cs);
            a2 = b21;
            b1 = -2 * ((A - 1) + (A + 1) * cs);
            b2 = a21;
        }

        a0 = a0 * A_inv;
        a1 = a1 * A_inv;
        a2 = a2 * A_inv;
    }

    public float process(float input) {
        float x = input;
        float y = a0 * x + a1 * x1 + a2 * x2 - b1 * y1 - b2 * y2;

        x2 = x1;
        x1 = x;
        y2 = y1;
        y1 = y;

        return y;
    }
}
