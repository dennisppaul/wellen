package wellen.tests.dsp.filters;

import wellen.Wellen;
import wellen.dsp.DSPNodeProcess;

import static java.lang.Math.sinh;
import static processing.core.PApplet.PI;
import static processing.core.PApplet.cos;
import static processing.core.PApplet.log;
import static processing.core.PApplet.pow;
import static processing.core.PApplet.sin;

/**
 * A Formant filter is a filter that is used to enhance or reduce the harmonic content of a sound at specific
 * frequencies. This is useful for creating a specific tonal quality or character in an audio signal. The center
 * frequency parameter is the frequency at which the filter will have the most effect, and the bandwidth parameter is
 * the range of frequencies around the center frequency that will be affected by the filter. The gain parameter is in dB
 * and it controls the amount of amplification or attenuation applied to the audio signal at the center frequency.
 * <p>
 * This class implements a 2nd order formant filter using the difference equation:
 * <p>
 * <code>y[n] = a0 * x[n] + a1 * x[n-1] + a2 * x[n-2] - b1 * y[n-1] - b2 * y[n-2]</code>
 * <p>
 * Where:
 * <ul>
 *     <li>x[n] is the input audio sample</li>
 *     <li>y[n] is the output audio sample</li>
 *     <li>a0, a1, a2, b1, b2 are the filter coefficients</li>
 *     <li>x1, x2, y1, y2 are previous inputs and outputs used for filtering</li>
 *     <li>centerFrequency is the center frequency of the filter</li>
 *     <li>bandwidth is the bandwidth of the filter</li>
 *     <li>gain is the gain of the filter</li>
 *     <li>sampleRate is the sample rate of the audio data</li>
 * </ul>
 */
public class FormantFilter implements DSPNodeProcess {

    private final float fSampleRate;
    // Filter coefficients
    private float a0, a1, a2, b1, b2;
    private float bandwidth;
    private float center;
    private float gain;
    private float x1, x2, y1, y2;

    public FormantFilter() {
        this(Wellen.DEFAULT_SAMPLING_RATE);
    }

    public FormantFilter(float sample_rate) {
        fSampleRate = sample_rate;
    }

    public float get_bandwidth() {
        return bandwidth;
    }

    public void set_bandwidth(float pBandwidth) {
        bandwidth = pBandwidth;
        update_coefficients();
    }

    public float get_center() {
        return center;
    }

    public void set_center(float pCenter) {
        center = pCenter;
        update_coefficients();
    }

    public float get_gain() {
        return gain;
    }

    public void set_gain(float pGain) {
        gain = pGain;
        update_coefficients();
    }

    public void update_coefficients() {
        float omega = 2 * PI * center / fSampleRate;
        float sn = sin(omega);
        float cs = cos(omega);
        float alpha = (float) (sn * sinh(log(2) / 2 * bandwidth * omega / sn));

        float A = pow(10, (gain / 40));
        float A_inv = 1 / A;

        a0 = 1 + alpha * A;
        a1 = -2 * cs;
        a2 = 1 - alpha * A;
        b1 = a1;
        b2 = (1 - alpha / A) / (1 + alpha / A);

        a0 = a0 * A_inv;
        a1 = a1 * A_inv;
        a2 = a2 * A_inv;
    }

    public float process(float input) {
        final float x = input;
        float y = a0 * x + a1 * x1 + a2 * x2 - b1 * y1 - b2 * y2;

        x2 = x1;
        x1 = x;
        y2 = y1;
        y1 = y;

        return y;
    }
}
