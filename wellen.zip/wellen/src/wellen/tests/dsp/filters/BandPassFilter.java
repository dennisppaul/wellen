package wellen.tests.dsp.filters;

import wellen.Wellen;

import static java.lang.Math.sinh;
import static processing.core.PApplet.PI;
import static processing.core.PApplet.cos;
import static processing.core.PApplet.log;
import static processing.core.PApplet.sin;

/**
 * Allows frequencies within a certain range (or band) to pass through while attenuating frequencies outside the band.
 * <p>
 * This class implements a 2nd order bandpass filter using the difference equation:
 * <p>
 * <code>y[n] = (a0 * x[n] + a1 * x[n-1] + a2 * x[n-2] - b1 * y[n-1] - b2 * y[n-2]) / a0</code>
 * <p>
 * Where:
 * <ul>
 *     <li>x[n] is the input audio sample</li>
 *     <li>y[n] is the output audio sample</li>
 *     <li>a0, a1, a2, b1, b2 are the filter coefficients</li>
 *     <li>x1, x2, y1, y2 are previous inputs and outputs used for filtering</li>
 *     <li>center is the center frequency of the filter</li>
 *     <li>bandwidth is the bandwidth of the filter</li>
 *     <li>sampleRate is the sample rate of the audio data</li>
 * </ul>
 * <p>
 * Bandwidth refers to the width of the passband of a filter. In other words, it is the range of frequencies that
 * are passed through the filter with minimal attenuation. The bandwidth of a filter is typically measured as the
 * difference between the upper and lower cutoff frequencies of the passband. For example, a bandpass filter with a
 * center frequency of 1kHz and a bandwidth of 200Hz would pass frequencies between 900Hz and 1100Hz with minimal
 * attenuation.
 * <p>
 * Resonance refers to the emphasis or enhancement of a particular frequency within the passband of a filter. It is
 * a measure of how much the filter will boost the amplitude of the frequencies near the center of the passband. For
 * example, a bandpass filter with a center frequency of 1kHz and a resonance of 2 would boost the amplitude of the
 * 1kHz frequency by a factor of 2, while still passing all other frequencies within the passband with minimal
 * attenuation.
 */

public class BandPassFilter {

    private final float fSampleRate;
    // Filter coefficients
    private float a0, a1, a2, b1, b2;
    private float bandwidth;
    private float center;
    private float x1, x2, y1, y2;

    public BandPassFilter() {
        this(Wellen.DEFAULT_SAMPLING_RATE);
    }

    public BandPassFilter(float sample_rate) {
        fSampleRate = sample_rate;
        bandwidth = 100;
        center = 2000;
        update_coefficients();
    }

    public float get_center() {
        return center;
    }

    public void set_center(float pCenter) {
        center = pCenter;
    }

    public float get_bandwidth() {
        return bandwidth;
    }

    public void set_bandwidth(float pBandwidth) {
        bandwidth = pBandwidth;
    }

    public void update_coefficients() {
        final float omega = 2 * PI * center / fSampleRate;
        final float sn = sin(omega);
        final float cs = cos(omega);
        final float alpha = (float) (sn * sinh(log(2) / 2 * bandwidth * omega / sn));

        a0 = 1 + alpha;
        a1 = -2 * cs;
        a2 = 1 - alpha;
        b1 = a1;
        b2 = (1 - alpha) / (1 + alpha);
    }

    public float process(float input) {
        final float x = input;
        final float y = (a0 * x + a1 * x1 + a2 * x2 - b1 * y1 - b2 * y2) / a0;

        x2 = x1;
        x1 = x;
        y2 = y1;
        y1 = y;

        return y;
    }
}
