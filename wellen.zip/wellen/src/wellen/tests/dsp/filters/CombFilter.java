package wellen.tests.dsp.filters;

import wellen.Wellen;
import wellen.dsp.DSPNodeProcess;

import java.util.Arrays;

/**
 * A comb filter is a filter that is used to create a specific frequency response with notches or peaks at specific
 * intervals. This is useful for creating specific effects such as echoes or flanging. The gain parameter in this
 * example controls the amplitude of the delayed signal, and the delayTime parameter is the time delay between the
 * original and delayed signals.
 * <p>
 * This class implements a comb filter using the difference equation:
 * <p>
 * <code>y[n] = gain * x[n - delay] + y[n - delay]</code>
 * <p>
 * Where:
 * <ul>
 *     <li>x[n] is the input audio sample</li>
 *     <li>y[n] is the output audio sample</li>
 *     <li>gain is the gain of the filter</li>
 *     <li>delayTime is the delay time of the filter in seconds</li>
 *     <li>sampleRate is the sample rate of the audio data</li>
 * </ul>
 */
public class CombFilter implements DSPNodeProcess {

    // Filter coefficients
    private final float[] b;
    private final int delay;
    private final float[] x;
    private final float[] y;
    private float gain;
    private int n;

    public CombFilter(float delayTime) {
        this(delayTime, Wellen.DEFAULT_SAMPLING_RATE);
    }

    public CombFilter(float delayTime, float sampleRate) {
        delay = (int) (delayTime * sampleRate);
        b = new float[delay];
        x = new float[delay];
        y = new float[delay];
    }

    public float get_gain() {
        return gain;
    }

    public void set_gain(float pGain) {
        gain = pGain;
        Arrays.fill(b, gain);
    }

    public float process(float input) {
        // TODO really need to check if this works or if n should always be 0?!?
        final int nn = n % delay;
        x[nn] = input;
        y[nn] = 0;
        for (int k = 0; k < delay; k++) {
            y[nn] += b[k] * x[(n - k + delay) % delay];
        }
        n++;
        return y[nn];
    }

    public void process(float[] input, float[] output) {
        for (int i = 0; i < input.length; i++) {
            x[i % delay] = input[i];
            y[i % delay] = 0;
            for (int k = 0; k < delay; k++) {
                y[i % delay] += b[k] * x[(i - k + delay) % delay];
            }
            output[i] = y[i % delay];
        }
    }
}
