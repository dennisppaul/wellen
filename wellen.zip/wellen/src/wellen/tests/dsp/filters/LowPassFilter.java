package wellen.tests.dsp.filters;

import wellen.Wellen;
import wellen.dsp.DSPNodeProcess;

import static processing.core.PApplet.PI;
import static processing.core.PApplet.cos;
import static processing.core.PApplet.sin;

/**
 * Allows frequencies below a certain cutoff frequency to pass through while attenuating frequencies above the cutoff.
 * <p>
 * This class implements a 2nd order low pass filter using the difference equation:
 * <p>
 * <code>y[n] = a0 * x[n] + a1 * x[n-1] + a2 * x[n-2] - b1 * y[n-1] - b2 * y[n-2]</code>
 * <p>
 * Where:
 * <ul>
 *     <li>x[n] is the input audio sample</li>
 *     <li>y[n] is the output audio sample</li>
 *     <li>a0, a1, a2, b1, b2 are filter coefficients</li>
 *     <li>x1, x2, y1, y2 are previous inputs and outputs used for filtering</li>
 * </ul>
 */
public class LowPassFilter implements DSPNodeProcess {

    private final float fSampleRate;
    // Filter coefficients
    private float a0, a1, a2, b1, b2;
    private float fCutoff;
    private float fResonance;
    private float x1, x2, y1, y2;

    public LowPassFilter() {
        this(Wellen.DEFAULT_SAMPLING_RATE);
    }

    public LowPassFilter(float sample_rate) {
        fSampleRate = sample_rate;
        fResonance = 0.4f;
        fCutoff = 1000.0f;
    }

    public float get_cutoff() {
        return fCutoff;
    }

    public void set_cutoff(float cutoff) {
        fCutoff = cutoff;
        update_coefficients();
    }

    public float get_resonance() {
        return fResonance;
    }

    public void set_resonance(float resonance) {
        fResonance = resonance;
        update_coefficients();
    }

    public void update_coefficients() {
        final float omega = 2 * PI * fCutoff / fSampleRate;
        final float sn = sin(omega);
        final float cs = cos(omega);
        final float alpha = sn / (2 * fResonance);

        a0 = (1 - cs) / 2;
        a1 = 1 - cs;
        a2 = a0;
        b1 = -2 * cs;
        b2 = (1 - alpha) / 2;
        x1 = x2 = y1 = y2 = 0;
    }

    public float process(float input) {
        final float x = input;
        final float y = a0 * x + a1 * x1 + a2 * x2 - b1 * y1 - b2 * y2;

        x2 = x1;
        x1 = x;
        y2 = y1;
        y1 = y;

        return y;
    }
}
