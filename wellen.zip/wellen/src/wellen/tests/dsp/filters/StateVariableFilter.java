package wellen.tests.dsp.filters;

import wellen.Wellen;
import wellen.dsp.DSPNodeProcess;

import static processing.core.PApplet.PI;
import static processing.core.PApplet.sin;

/**
 * A state variable filter is a type of filter that is able to provide multiple outputs from a single input, such as
 * low-pass, high-pass, band-pass, and notch outputs. It achieves this by using a set of internal states (v1 and v2 in
 * this example) that are updated with each input sample, and then combined in different ways to provide the various
 * filter outputs. The cutoff frequency and resonance parameters control the cutoff frequency and Q factor of the
 * filter, respectively, and the gain parameter controls the overall output gain.
 * <p>
 * This class implements a state variable filter using the difference equation:
 * <p>
 * <code>y[n] = gain * (v2[n])</code>
 * <p>
 * Where:
 * <ul>
 *     <li>v0[n] is the input audio sample</li>
 *     <li>v1[n] and v2[n] are the intermediate filter states</li>
 *     <li>gain is the gain of the filter</li>
 *     <li>cutoff is the cutoff frequency of the filter</li>
 *     <li>resonance is the Q factor of the filter</li>
 *     <li>sample_rate is the sample rate of the audio data</li>
 * </ul>
 */
public class StateVariableFilter implements DSPNodeProcess {

    private final float fSampleRate;
    private float cutoff;
    // Filter coefficients
    private float f, q;
    private float gain;
    private float k, a, b, c;
    private float resonance;
    private float v0, v1, v2;
    private float x1, x2, y1, y2;

    public StateVariableFilter() {
        this(Wellen.DEFAULT_SAMPLING_RATE);
    }

    public StateVariableFilter(float sample_rate) {
        fSampleRate = sample_rate;
    }

    public float get_gain() {
        return gain;
    }

    public void set_gain(float pGain) {
        gain = pGain;
    }

    public float get_cutoff() {
        return cutoff;
    }

    public void set_cutoff(float pCutoff) {
        cutoff = pCutoff;
        update_coefficients();
    }

    public float get_resonance() {
        return resonance;
    }

    public void set_resonance(float pResonance) {
        resonance = pResonance;
        update_coefficients();
    }

    public void update_coefficients() {
        f = 2 * sin(PI * cutoff / fSampleRate);
        q = 1 / resonance;
        x1 = x2 = y1 = y2 = 0;
        v0 = v1 = v2 = 0;
    }

    public float process(float input) {
        final float x = input;
        k = (v0 - q * v1) * f;
        a = k + v1;
        b = -k + v1;
        c = v2;
        v2 = b;
        v1 = a;
        return v2 * gain;
    }

    public float low_pass(float input) {
        return process(input);
    }

    public float high_pass(float input) {
        return input - process(input);
    }

    public float band_pass(float input) {
        process(input);
        return v1;
    }

    public float notch(float input) {
        return input - process(input) * 2;
    }
}
