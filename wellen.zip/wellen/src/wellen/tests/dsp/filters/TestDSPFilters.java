package wellen.tests.dsp.filters;

import processing.core.PApplet;
import wellen.Wellen;
import wellen.dsp.DSP;
import wellen.dsp.Wavetable;

public class TestDSPFilters extends PApplet {

    private final Wavetable mWavetable = new Wavetable();
    // GOOD
    // NOT GOOD
    AllPassFilter fAllPassFilter = new AllPassFilter();
    BandPassFilter fBandPassFilter = new BandPassFilter();
    LowPassFilter fLowPassFilter = new LowPassFilter();
    HighPassFilter fHighPassFilter = new HighPassFilter();
    // TEST
    BandStopFilter fBandStopFilter = new BandStopFilter();
    CombFilter fCombFilter = new CombFilter(1.0f);
    FormantFilter fFormantFilter = new FormantFilter();
    NotchFilter fNotchFilter = new NotchFilter();
    PeakingFilter fPeakingFilter = new PeakingFilter();
    ShelvingFilter fShelvingFilter = new ShelvingFilter();
    PhaserFilter fPhaserFilter = new PhaserFilter();
    StateVariableFilter fStateVariableFilter = new StateVariableFilter();

    public void settings() {
        size(640, 480);
    }

    public void setup() {
        Wavetable.fill(mWavetable.get_wavetable(), Wellen.OSC_SAWTOOTH);
        mWavetable.set_frequency(2.0f * Wellen.DEFAULT_SAMPLING_RATE / Wellen.DEFAULT_AUDIOBLOCK_SIZE);
        mWavetable.set_amplitude(0.33f);

        DSP.start(this);
    }

    public void draw() {
        background(255);
        DSP.draw_buffers(g, width, height);
    }

    public void keyPressed() {
        switch (key) {
            case '1':
                break;
            case '2':
                break;
            case '3':
                break;
            case '4':
                Wavetable.fill(mWavetable.get_wavetable(), Wellen.OSC_SAWTOOTH);
                break;
            case '5':
                Wavetable.fill(mWavetable.get_wavetable(), Wellen.OSC_SQUARE);
                break;
            case '6':
                mWavetable.set_frequency(2.0f * Wellen.DEFAULT_SAMPLING_RATE / Wellen.DEFAULT_AUDIOBLOCK_SIZE);
                break;
            case '7':
                mWavetable.set_frequency(1.0f * Wellen.DEFAULT_SAMPLING_RATE / Wellen.DEFAULT_AUDIOBLOCK_SIZE);
                break;
        }
    }

    public void mouseMoved() {
        fAllPassFilter.set_cutoff(map(mouseX, 0, width, 1.0f, Wellen.DEFAULT_SAMPLING_RATE * 0.5f));
//        fBandPassFilter.set_center(map(mouseY, 0, height, 1.0f, Wellen.DEFAULT_SAMPLING_RATE * 0.5f));
    }

    public void audioblock(float[] output_signal) {
        for (int i = 0; i < output_signal.length; i++) {
            output_signal[i] = mousePressed ? mWavetable.output() : fAllPassFilter.process(mWavetable.output());
        }
    }

    public static void main(String[] args) {
        PApplet.main(TestDSPFilters.class.getName());
    }
}