package wellen.tests.dsp.filters;


import wellen.Wellen;
import wellen.dsp.DSPNodeProcess;

import static java.lang.Math.sinh;
import static processing.core.PApplet.PI;
import static processing.core.PApplet.cos;
import static processing.core.PApplet.log;
import static processing.core.PApplet.pow;
import static processing.core.PApplet.sin;

/**
 * Amplifies or attenuates a specific range of frequencies around a center frequency, also known as a parametric
 * equalizer.
 * <p>
 * This class implements a 2nd order peaking filter using the difference equation:
 * <p>
 * <code>y[n] = a0 * x[n] + a1 * x[n-1] + a2 * x[n-2] - b1 * y[n-1] - b2 * y[n-2]</code>
 * <p>
 * Where:
 * <ul>
 *     <li>x[n] is the input audio sample</li>
 *     <li>y[n] is the output audio sample</li>
 *     <li>a0, a1, a2, b0, b1, b2 are the filter coefficients</li>
 *     <li>x1, x2, y1, y2 are previous inputs and outputs used for filtering</li>
 *     <li>center is the center frequency of the filter</li>
 *     <li>bandwidth is the bandwidth of the filter</li>
 *     <li>gain is the gain of the filter</li>
 *     <li>resonance is the resonance of the filter</li>
 *     <li>sampleRate is the sample rate of the audio data</li>
 * </ul>
 */
public class PeakingFilter implements DSPNodeProcess {

    private final float fSampleRate;
    // Filter coefficients
    private float center;
    private float fc, bandwidth, gain, resonance;
    private float a0, a1, a2, b0, b1, b2;
    private float x1, x2, y1, y2;

    public PeakingFilter() {
        this(Wellen.DEFAULT_SAMPLING_RATE);
    }

    public PeakingFilter(float sample_rate) {
        fSampleRate = sample_rate;
    }

    public float get_center() {
        return center;
    }

    public void set_center(float pCenter) {
        center = pCenter;
        update_coefficients();
    }

    public float get_bandwidth() {
        return bandwidth;
    }

    public void set_bandwidth(float pBandwidth) {
        bandwidth = pBandwidth;
        update_coefficients();
    }

    public float get_gain() {
        return gain;
    }

    public void set_gain(float pGain) {
        gain = pGain;
        update_coefficients();
    }

    public float get_resonance() {
        return resonance;
    }

    public void set_resonance(float pResonance) {
        resonance = pResonance;
        update_coefficients();
    }

    public void update_coefficients() {
        fc = 2 * sin(PI * center / fSampleRate);
        float A = pow(10, gain / 40);
        float alpha = (float) (sin(fc) * sinh(log(2) / 2 * bandwidth * fc / sin(fc)));
        b0 = (1 + alpha * A);
        b1 = (-2 * cos(fc));
        b2 = (1 - alpha * A);
        a0 = (1 + alpha / A);
        a1 = (-2 * cos(fc));
        a2 = (1 - alpha / A);
        x1 = x2 = y1 = y2 = 0; // TODO is this necessary?
    }

    public float process(float input) {
        float output = (b0 / a0) * input + (b1 / a0) * x1 + (b2 / a0) * x2 - (a1 / a0) * y1 - (a2 / a0) * y2;
        x2 = x1;
        x1 = input;
        y2 = y1;
        y1 = output;
        return output;
    }
}
