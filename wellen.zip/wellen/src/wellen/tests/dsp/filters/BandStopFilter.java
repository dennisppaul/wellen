package wellen.tests.dsp.filters;

import wellen.Wellen;

import static java.lang.Math.sinh;
import static processing.core.PApplet.PI;
import static processing.core.PApplet.cos;
import static processing.core.PApplet.log;
import static processing.core.PApplet.sin;

/**
 * Attenuates frequencies within a certain range (or band) while allowing frequencies outside the band to pass through.
 * <p>
 * This class implements a 2nd order bandstop filter using the difference equation:
 * <p>
 * <code>y[n] = (a0 * x[n] + a1 * x[n-1] + a2 * x[n-2] - b1 * y[n-1] - b2 * y[n-2]) / a0</code>
 * <p>
 * Where:
 * <ul>
 *     <li>x[n] is the input audio sample</li>
 *     <li>y[n] is the output audio sample</li>
 *     <li>a0, a1, a2, b1, b2 are the filter coefficients</li>
 *     <li>x1, x2, y1, y2 are previous inputs and outputs used for filtering</li>
 *     <li>center is the center frequency of the filter</li>
 *     <li>bandwidth is the bandwidth of the filter</li>
 *     <li>resonance is the resonance of the filter</li>
 *     <li>sampleRate is the sample rate of the audio data</li>
 * </ul>
 */
public class BandStopFilter {

    private final float fSampleRate;
    // Filter coefficients
    private float a0, a1, a2, b1, b2;
    private float bandwidth;
    private float center;
    private float cutoff;
    private float resonance;
    private float x1, x2, y1, y2;

    public BandStopFilter() {
        this(Wellen.DEFAULT_SAMPLING_RATE);
    }

    public BandStopFilter(float sample_rate) {
        fSampleRate = sample_rate;
    }

    public float get_center() {
        return center;
    }

    public void set_center(float pCenter) {
        center = pCenter;
        update_coefficients();
    }

    public float get_bandwidth() {
        return bandwidth;
    }

    public void set_bandwidth(float pBandwidth) {
        bandwidth = pBandwidth;
        update_coefficients();
    }

    public float get_cutoff() {
        return cutoff;
    }

    public void set_cutoff(float pCutoff) {
        cutoff = pCutoff;
        update_coefficients();
    }

    public float get_resonance() {
        return resonance;
    }

    public void set_resonance(float pResonance) {
        resonance = pResonance;
        update_coefficients();
    }

    public void update_coefficients() {
        final float omega = 2 * PI * center / fSampleRate;
        final float sn = sin(omega);
        final float cs = cos(omega);
        final float alpha = (float) (sn * sinh(log(2) / 2 * bandwidth * omega / sn));

        a0 = (1 + alpha);
        a1 = -2 * cs;
        a2 = (1 - alpha);
        b1 = a1;
        b2 = (1 - alpha) / (1 + alpha);
    }

    public float process(float input) {
        final float x = input;
        final float y = (a0 * x + a1 * x1 + a2 * x2 - b1 * y1 - b2 * y2) / a0;

        x2 = x1;
        x1 = x;
        y2 = y1;
        y1 = y;

        return y;
    }
}
