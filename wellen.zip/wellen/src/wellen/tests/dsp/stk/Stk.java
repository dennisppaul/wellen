package wellen.tests.dsp.stk;

import wellen.Wellen;

public class Stk {
    public static float sampleRate() {
        return Wellen.DEFAULT_SAMPLING_RATE;
    }
}
