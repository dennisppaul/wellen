package wellen.tests.dsp.tarsos;


import java.util.ArrayList;
import java.util.Arrays;

/**
 * Granulator plays back samples using granular synthesis. Methods can be used to control playback rate, pitch, grain
 * size, grain interval and grain randomness and position (this last case assumes that the playback rate is zero).
 *
 * @author ollie
 * @author Joren
 */
public class Granulator {

    public static final float ADAPTIVE_INTERP_HIGH_THRESH = 2.5f;
    public static final float ADAPTIVE_INTERP_LOW_THRESH = 0.5f;
    /**
     * The position in milliseconds.
     */
    protected double position;
    private final float[] audioBuffer;
    private int audioBufferWatermark;
    /**
     * A list of dead grains.
     */
    private final ArrayList<Grain> deadGrains;
    /**
     * Flag to indicate special case for the first grain.
     */
    private boolean firstGrain = true;
    /**
     * A list of free grains.
     */
    private final ArrayList<Grain> freeGrains;
    private float grainInterval;
    private float grainRandomness;
    private float grainSize;
    /**
     * The list of current grains.
     */
    private final ArrayList<Grain> grains;
    /**
     * The length of one sample in milliseconds.
     */
    private final double msPerSample;
    private final float[] outputBuffer;

    ///** The interpolation type. */
    //protected InterpolationType interpolationType;
    /**
     * The pitch, bound to the pitch envelope.
     */
    private float pitchFactor;
    /**
     * The millisecond position increment per sample. Calculated from the ratio of the AudioContext's sample rate and
     * the sample’s sample rate.
     */
    private final double positionIncrement;
    /**
     * The time in milliseconds since the last grain was activated.
     */
    private float timeSinceLastGrain;
    /**
     * The pitch, bound to the pitch envelope.
     */
    private float timeStretchFactor;
    /**
     * The window used by grains.
     */
    private final float[] window;
    /**
     * Instantiates a new GranularSamplePlayer.
     *
     * @param sampleRate the sample rate.
     * @param bufferSize the size of an output buffer.
     */
    public Granulator(float sampleRate, int bufferSize) {
        grains = new ArrayList<>();
        freeGrains = new ArrayList<>();
        deadGrains = new ArrayList<>();

        // TODO(wait a minute: 12*60*48000=34560000 that s 33MB of buffer space … hmmmm )
        audioBuffer = new float[(int) (12 * 60 * sampleRate)];// max 12 minutes of audio
        audioBufferWatermark = 0;

        pitchFactor = 1.0f;

        grainInterval = 40.0f;
        grainSize = 100.0f;
        grainRandomness = 0.1f;

        window = new CosineWindow().generateCurve(bufferSize);
        outputBuffer = new float[bufferSize];

        msPerSample = 1000.0f / sampleRate;

        positionIncrement = msPerSample;
    }

    public void start() {
        timeSinceLastGrain = 0;
    }

    public boolean process(float[] signal_buffer) {
        System.arraycopy(signal_buffer, 0, audioBuffer, audioBufferWatermark, signal_buffer.length);
        audioBufferWatermark += signal_buffer.length;

        // grains.clear();
        // position = audioEvent.getTimeStamp()*1000 - 5000;

        // reset output
        Arrays.fill(outputBuffer, 0);

        firstGrain();

        // now loop through the buffer
        for (int i = 0; i < signal_buffer.length; i++) {
            // determine if we need a new grain
            if (timeSinceLastGrain > grainInterval) {
                Grain g;
                if (freeGrains.size() > 0) {
                    g = freeGrains.get(0);
                    freeGrains.remove(0);
                } else {
                    g = new Grain();
                }
                g.reset(grainSize, grainRandomness, position, timeStretchFactor, pitchFactor);
                grains.add(g);
                timeSinceLastGrain = 0f;
                //System.out.println(grains.size());
            }

            // gather the output from each grain
            for (Grain g : grains) {
                // calculate value of grain window
                float windowScale = getValueFraction((float) (g.age / g.grainSize));
                // get position in sample for this grain
                // get the frame for this grain

                double sampleValue;
                getFrameLinear(g.position);
                if (pitchFactor > ADAPTIVE_INTERP_HIGH_THRESH) {
                    sampleValue = getFrameNoInterp(g.position);
                } else if (pitchFactor > ADAPTIVE_INTERP_LOW_THRESH) {
                    sampleValue = getFrameLinear(g.position);
                } else {
                    sampleValue = getFrameCubic(g.position);
                }
                sampleValue = sampleValue * windowScale;
                outputBuffer[i] += (float) sampleValue;
            }
            // increment time
            position += positionIncrement * timeStretchFactor;

            for (Grain g : grains) {
                calculateNextGrainPosition(g);
            }
            // increment timeSinceLastGrain
            timeSinceLastGrain += msPerSample;
            // finally, see if any grains are dead
            for (Grain g : grains) {
                if (g.age > g.grainSize) {
                    freeGrains.add(g);
                    deadGrains.add(g);
                }
            }
            for (Grain g : deadGrains) {
                grains.remove(g);
            }
            deadGrains.clear();
        }
        System.arraycopy(outputBuffer, 0, signal_buffer, 0, signal_buffer.length);

        return true;
    }

    /**
     * Retrieves a frame of audio using linear interpolation. If the frame is not in the sample range then zeros are
     * returned.
     *
     * @param posInMS The frame to read -- can be fractional (e.g., 4.4).
     */
    public double getFrameLinear(double posInMS) {
        double result = 0.0;
        double sampleNumber = msToSamples(posInMS);
        int sampleNumberFloor = (int) Math.floor(sampleNumber);
        if (sampleNumberFloor > 0 && sampleNumberFloor < audioBufferWatermark) {
            double sampleNumberFraction = sampleNumber - sampleNumberFloor;
            if (sampleNumberFloor == audioBufferWatermark - 1) {
                result = audioBuffer[sampleNumberFloor];
            } else {
                // linear interpolation
                double current = audioBuffer[sampleNumberFloor];
                double next = audioBuffer[sampleNumberFloor];
                result = (float) ((1 - sampleNumberFraction) * current + sampleNumberFraction * next);
            }
        }
        return result;
    }

    /**
     * Retrieves a frame of audio using no interpolation. If the frame is not in the sample range then zeros are
     * returned.
     *
     * @param posInMS The frame to read -- will take the last frame before this one.
     */
    public float getFrameNoInterp(double posInMS) {
        double frame = msToSamples(posInMS);
        int frame_floor = (int) Math.floor(frame);
        return audioBuffer[frame_floor];
    }

    /**
     * Retrieves a frame of audio using cubic interpolation. If the frame is not in the sample range then zeros are
     * returned.
     *
     * @param posInMS The frame to read -- can be fractional (e.g., 4.4).
     */
    public float getFrameCubic(double posInMS) {
        float frame = (float) msToSamples(posInMS);
        float result = 0.0f;
        float a0, a1, a2, a3, mu2;
        float ym1, y0, y1, y2;

        int realCurrentSample = (int) Math.floor(frame);
        float fractionOffset = (frame - (float) realCurrentSample);

        if (realCurrentSample >= 0 && realCurrentSample < (audioBufferWatermark - 1)) {
            realCurrentSample--;
            if (realCurrentSample < 0) {
                ym1 = audioBuffer[0];
                realCurrentSample = 0;
            } else {
                ym1 = audioBuffer[realCurrentSample++];
            }
            y0 = audioBuffer[realCurrentSample++];
            if (realCurrentSample >= audioBufferWatermark) {
                y1 = audioBuffer[audioBufferWatermark - 1]; // ??
            } else {
                y1 = audioBuffer[realCurrentSample++];
            }
            if (realCurrentSample >= audioBufferWatermark) {
                y2 = audioBuffer[audioBufferWatermark - 1];
            } else {
                y2 = audioBuffer[realCurrentSample++];
            }
            mu2 = fractionOffset * fractionOffset;
            a0 = y2 - y1 - ym1 + y0;
            a1 = ym1 - y0 - a0;
            a2 = y1 - ym1;
            a3 = y0;
            result = a0 * fractionOffset * mu2 + a1 * mu2 + a2 * fractionOffset + a3;
        }
        return result;
    }

    /**
     * Returns the value of the buffer at the given fraction along its length (0 = start, 1 = end). Uses linear
     * interpolation.
     *
     * @param fraction the point along the buffer to inspect.
     * @return the value at that point.
     */
    public float getValueFraction(float fraction) {
        float posInBuf = fraction * window.length;
        int lowerIndex = (int) posInBuf;
        float offset = posInBuf - lowerIndex;
        int upperIndex = (lowerIndex + 1) % window.length;
        return (1 - offset) * window[lowerIndex] + offset * window[upperIndex];
    }

    public void setTimestretchFactor(float currentFactor) {
        timeStretchFactor = currentFactor;
    }

    public void setPitchShiftFactor(float currentFactor) {
        pitchFactor = currentFactor;
    }

    public void setGrainInterval(int grainInterval) {
        this.grainInterval = grainInterval;
    }

    public void setGrainSize(int grainSize) {
        this.grainSize = grainSize;

    }

    public void setGrainRandomness(float grainRandomness) {
        this.grainRandomness = grainRandomness;
    }

    /**
     * @param position in seconds
     */
    public void setPosition(float position) {
        this.position = position * 1000;
    }

    /**
     * Calculate next position for the given Grain.
     *
     * @param g the Grain.
     */
    private void calculateNextGrainPosition(Grain g) {
        int direction = timeStretchFactor >= 0 ? 1 : -1;    //this is a bit odd in the case when controlling grain
        // from positionEnvelope
        g.age += msPerSample;
        g.position += direction * positionIncrement * pitchFactor;
    }

    /**
     * Special case method for playing first grain.
     */
    private void firstGrain() {
        if (firstGrain) {
            Grain g = new Grain();
            g.position = position;
            g.age = grainSize / 4f;
            g.grainSize = grainSize;

            grains.add(g);
            firstGrain = false;
            timeSinceLastGrain = grainInterval / 2f;
        }
    }

    private double msToSamples(double posInMs) {
        return (posInMs) / msPerSample;
    }
}

