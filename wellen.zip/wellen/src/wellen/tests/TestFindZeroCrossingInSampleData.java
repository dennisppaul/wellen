package wellen.tests;

import processing.core.PApplet;

public class TestFindZeroCrossingInSampleData extends PApplet {

    public void settings() {
        size(640, 480);
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(TestFindZeroCrossingInSampleData.class.getName());
    }
}

