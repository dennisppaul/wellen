package wellen.tests.rakarrack;

public class RRFilter {
    public float outgain;

    public void filterout(float[] smp) {
    }

    public void setfreq(float frequency) {
    }

    public void setfreq_and_q(float frequency, float q_) {
    }

    public void setq(float q_) {
    }

    public void setgain(float dBgain) {
    }
}
