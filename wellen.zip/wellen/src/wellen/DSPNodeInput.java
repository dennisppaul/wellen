package wellen;

public interface DSPNodeInput {
    void input(float pSignal);
}
