package wellen;

/**
 * interface implemented by classes that accept input signals.
 */
public interface DSPNodeInput {
    void input(float pSignal);
}
