package wellen;

public interface EnvelopeListener {
    void envelope_done(Envelope pEnvelope);
}
