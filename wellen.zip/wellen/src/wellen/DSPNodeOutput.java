package wellen;

public interface DSPNodeOutput {
    float output();
}
