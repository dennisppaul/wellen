# ton

a library that acts as a simple adapter to various outputs like JSyn, MIDI, or OSC.

## dependencies

- [JSyn](https://github.com/philburk/jsyn/) *included in the distribution*
- [Minim](http://code.compartmental.net/tools/minim/) *installed via processing library installer*
- [oscP5](http://sojamo.de/code/) *installed via processing library installer*
- [controlP5](http://sojamo.de/code/) *installed via processing library installer*
- [video](https://processing.org/reference/libraries/video/) *installed via processing library installer* 
