package de.hfkbremen.ton.applications;

import processing.core.PApplet;

public class AppAlgorithmicComposition02VisualModel extends PApplet {

    //@todo(record from mic)
    //@todo(position circle)

    public void settings() {
        size(640, 480);
    }

    public void setup() {
    }

    public void draw() {
        background(255);
    }

    public static void main(String[] args) {
        PApplet.main(AppAlgorithmicComposition02VisualModel.class.getName());
    }
}