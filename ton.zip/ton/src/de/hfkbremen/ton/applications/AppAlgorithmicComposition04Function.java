package de.hfkbremen.ton.applications;

import processing.core.PApplet;

public class AppAlgorithmicComposition04Function extends PApplet {

    // @todo(add sinewaves that trigger notes)

    public void settings() {
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(AppAlgorithmicComposition04Function.class.getName());
    }
}
