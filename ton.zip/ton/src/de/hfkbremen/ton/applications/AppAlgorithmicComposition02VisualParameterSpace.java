package de.hfkbremen.ton.applications;

import processing.core.PApplet;

public class AppAlgorithmicComposition02VisualParameterSpace extends PApplet {

    //@todo(record from mic)
    //@todo(position circle)

    public void settings() {
        size(640, 480);
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(AppAlgorithmicComposition02VisualParameterSpace.class.getName());
    }
}