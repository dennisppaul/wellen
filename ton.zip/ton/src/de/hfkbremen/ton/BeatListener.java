package de.hfkbremen.ton;

public interface BeatListener {
    void beat(int pBeatCount);
}
