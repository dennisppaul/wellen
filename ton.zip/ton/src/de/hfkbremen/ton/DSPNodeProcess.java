package de.hfkbremen.ton;

public interface DSPNodeProcess {

    float process(float pSignal);
}
