package de.hfkbremen.ton;

public interface DSPNodeOutput {
    float output();
}
