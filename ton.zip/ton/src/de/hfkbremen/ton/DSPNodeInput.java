package de.hfkbremen.ton;

public interface DSPNodeInput {
    void input(float pSignal);
}
