package ton;

public interface DSPNodeOutput {
    float output();
}
