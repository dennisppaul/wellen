package ton;

public interface DSPNodeInput {
    void input(float pSignal);
}
