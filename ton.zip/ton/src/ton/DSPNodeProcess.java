package ton;

public interface DSPNodeProcess {

    float process(float pSignal);
}
