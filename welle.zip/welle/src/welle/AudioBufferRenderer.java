package welle;

public interface AudioBufferRenderer {

    void audioblock(float[][] pOutputSamples, float[][] pInputSamples);
}
