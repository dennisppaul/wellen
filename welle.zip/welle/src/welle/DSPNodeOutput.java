package welle;

public interface DSPNodeOutput {
    float output();
}
