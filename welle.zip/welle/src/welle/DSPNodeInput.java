package welle;

public interface DSPNodeInput {
    void input(float pSignal);
}
