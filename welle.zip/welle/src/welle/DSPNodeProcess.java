package welle;

public interface DSPNodeProcess {

    float process(float pSignal);
}
