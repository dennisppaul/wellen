package welle;

public interface BeatListener {

    void beat(int pBeatCount);
}
